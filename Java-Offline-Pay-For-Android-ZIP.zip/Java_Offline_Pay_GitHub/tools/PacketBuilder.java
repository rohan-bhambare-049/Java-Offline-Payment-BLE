import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.HexFormat;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * PacketBuilder: a standalone test helper for the Java Offline Pay
 * Bluetooth Mesh backend.
 *
 * It builds exactly one genuine, encrypted MeshPacket, in the same
 * format a sender phone builds, so the backend bridge endpoint can
 * be tested from Postman or curl without an Android phone.
 *
 * This file has no project dependencies and no third party
 * dependencies. It uses only the Java standard library, so it
 * compiles and runs with a plain JDK, version 17 or newer:
 *
 *   javac PacketBuilder.java
 *
 * Mode 1: you already have the server public key. Get it from
 * GET /api/v1/mesh/server-public-key while logged in, then run:
 *
 *   java PacketBuilder <publicKeyBase64> <senderAccount> <receiverAccount> <amount>
 *
 * Mode 2: fetch the public key from a running backend:
 *
 *   java PacketBuilder --fetch <baseUrl> <email> <password> <senderAccount> <receiverAccount> <amount>
 *
 * In both modes you may add, in any order after the required
 * arguments:
 *
 *   --output <file>        output file, default: packet.json
 *   --origin <deviceId>    origin device id, default: phone-sender
 *   --ttl <number>         packet TTL, default: 5
 *
 * Example, backend on the local machine, sender and receiver are
 * 16 digit account numbers from GET /api/v1/accounts/me:
 *
 *   java PacketBuilder --fetch http://localhost:8080 sender@example.com SenderPass1234 7155445402273003 7999922411051701 250.00
 *
 * The output file is then the request body for:
 *
 *   POST /api/v1/mesh/bridge/ingest
 *
 * with HTTP Basic authentication and the optional header
 * X-Bridge-Node-Id. The expected first response is SETTLED.
 * Sending the same file a second time must return
 * DUPLICATE_DROPPED, with no second debit.
 *
 * Security notes, read before use:
 * - This tool needs only the server PUBLIC key. It never needs,
 *   asks for, or prints the server private key. Never paste a
 *   private key into this tool, into Postman, or into a chat.
 * - The packet it builds is a real payment instruction once it
 *   reaches the backend. Test only with accounts you control,
 *   and only against a backend you control.
 * - A packet is valid for 24 hours from creation, with a
 *   5 minute clock skew allowance on the server. Build a fresh
 *   packet if an old file returns EXPIRED.
 */
public class PacketBuilder {

    private static final String RSA_TRANSFORMATION = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding";
    private static final String AES_TRANSFORMATION = "AES/GCM/NoPadding";
    private static final int AES_KEY_BITS = 256;
    private static final int GCM_TAG_BITS = 128;
    private static final int GCM_IV_BYTES = 12;
    private static final String CURRENCY = "INR";

    public static void main(String[] args) throws Exception {
        // Set before any networking, so a local test server bound
        // to IPv4 is reached directly instead of through an
        // IPv6 mapped address, which some test VMs reset.
        System.setProperty("java.net.preferIPv4Stack", "true");

        if (args.length == 0 || hasFlag(args, "--help") || hasFlag(args, "-h")) {
            printUsage();
            return;
        }

        String publicKeyBase64;
        String sender;
        String receiver;
        String amountText;
        String outputFile = "packet.json";
        String originDeviceId = "phone-sender";
        int ttl = 5;

        if ("--fetch".equals(args[0])) {
            if (args.length < 6) {
                System.err.println("Missing arguments for --fetch mode.");
                printUsage();
                System.exit(2);
            }
            String baseUrl = stripTrailingSlash(args[1]);
            String email = args[2];
            String password = args[3];
            sender = args[4];
            receiver = args[5];
            amountText = args[6];
            publicKeyBase64 = fetchPublicKey(baseUrl, email, password);
            String[] rest = new String[args.length - 7];
            System.arraycopy(args, 7, rest, 0, rest.length);
            String[] parsed = parseOptions(rest);
            outputFile = parsed[0];
            originDeviceId = parsed[1];
            ttl = Integer.parseInt(parsed[2]);
        } else {
            if (args.length < 4) {
                System.err.println("Missing arguments.");
                printUsage();
                System.exit(2);
            }
            publicKeyBase64 = args[0];
            sender = args[1];
            receiver = args[2];
            amountText = args[3];
            String[] rest = new String[args.length - 4];
            System.arraycopy(args, 4, rest, 0, rest.length);
            String[] parsed = parseOptions(rest);
            outputFile = parsed[0];
            originDeviceId = parsed[1];
            ttl = Integer.parseInt(parsed[2]);
        }

        validateAccount(sender, "sender");
        validateAccount(receiver, "receiver");
        if (sender.equals(receiver)) {
            throw new IllegalArgumentException("Sender and receiver accounts must be different.");
        }
        BigDecimal amount = new BigDecimal(amountText);
        if (amount.signum() <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero.");
        }
        if (amount.scale() > 2) {
            throw new IllegalArgumentException("Amount may have at most 2 decimal places.");
        }
        if (ttl < 0) {
            throw new IllegalArgumentException("TTL cannot be negative.");
        }
        if (originDeviceId == null || originDeviceId.isBlank()) {
            throw new IllegalArgumentException("Origin device id must not be blank.");
        }

        PublicKey publicKey = decodePublicKey(publicKeyBase64);

        UUID paymentId = UUID.randomUUID();
        long createdAt = System.currentTimeMillis();
        String payloadHash = paymentHash(paymentId, sender, receiver, amount, CURRENCY, createdAt);
        String payloadJson = payloadJson(paymentId, sender, receiver, amount, CURRENCY, createdAt, payloadHash);
        String ciphertext = encrypt(publicKey, payloadJson.getBytes(StandardCharsets.UTF_8));

        UUID packetId = UUID.randomUUID();
        String packetJson = packetJson(packetId, originDeviceId, createdAt, ttl, 0, ciphertext);

        Path output = Path.of(outputFile);
        Files.writeString(output, packetJson, StandardCharsets.UTF_8);

        String packetHash = sha256Hex(Base64.getDecoder().decode(ciphertext));
        System.out.println("Packet written to: " + output.toAbsolutePath());
        System.out.println("paymentId: " + paymentId);
        System.out.println("packetId: " + packetId);
        System.out.println("packetHash (SHA256 of ciphertext): " + packetHash);
        System.out.println("sender: " + sender);
        System.out.println("receiver: " + receiver);
        System.out.println("amount: " + amount.toPlainString() + " " + CURRENCY);
        System.out.println("Next step: POST this file as the body of /api/v1/mesh/bridge/ingest");
        System.out.println("with HTTP Basic authentication. First delivery should return SETTLED.");
    }

    private static void printUsage() {
        System.out.println("Usage:");
        System.out.println("  java PacketBuilder <publicKeyBase64> <senderAccount> <receiverAccount> <amount> [--output <file>] [--origin <deviceId>] [--ttl <number>]");
        System.out.println("  java PacketBuilder --fetch <baseUrl> <email> <password> <senderAccount> <receiverAccount> <amount> [--output <file>] [--origin <deviceId>] [--ttl <number>]");
        System.out.println("Accounts must be 16 digits. Amount must be positive with at most 2 decimal places. Currency is INR only, matching the backend.");
    }

    private static boolean hasFlag(String[] args, String flag) {
        for (String arg : args) {
            if (flag.equals(arg)) {
                return true;
            }
        }
        return false;
    }

    private static String[] parseOptions(String[] rest) {
        String outputFile = "packet.json";
        String originDeviceId = "phone-sender";
        String ttl = "5";
        for (int i = 0; i < rest.length; i++) {
            switch (rest[i]) {
                case "--output" -> {
                    if (i + 1 >= rest.length) {
                        throw new IllegalArgumentException("Missing value for --output.");
                    }
                    outputFile = rest[++i];
                }
                case "--origin" -> {
                    if (i + 1 >= rest.length) {
                        throw new IllegalArgumentException("Missing value for --origin.");
                    }
                    originDeviceId = rest[++i];
                }
                case "--ttl" -> {
                    if (i + 1 >= rest.length) {
                        throw new IllegalArgumentException("Missing value for --ttl.");
                    }
                    ttl = rest[++i];
                }
                default -> throw new IllegalArgumentException("Unknown option: " + rest[i]);
            }
        }
        return new String[]{outputFile, originDeviceId, ttl};
    }

    private static String stripTrailingSlash(String value) {
        while (value.endsWith("/")) {
            value = value.substring(0, value.length() - 1);
        }
        return value;
    }

    private static String fetchPublicKey(String baseUrl, String email, String password) throws IOException {
        String url = baseUrl + "/api/v1/mesh/server-public-key";
        HttpURLConnection connection = (HttpURLConnection) URI.create(url).toURL().openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(10_000);
        connection.setReadTimeout(10_000);
        String credentials = Base64.getEncoder()
                .encodeToString((email + ":" + password).getBytes(StandardCharsets.UTF_8));
        connection.setRequestProperty("Authorization", "Basic " + credentials);
        connection.setRequestProperty("Accept", "application/json");
        int status = connection.getResponseCode();
        InputStream body = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
        String response = body == null ? "" : new String(body.readAllBytes(), StandardCharsets.UTF_8);
        if (status < 200 || status >= 300) {
            throw new IllegalStateException("Could not fetch server public key, HTTP " + status + ": " + response);
        }
        String key = readJsonString(response, "publicKeyBase64");
        if (key == null || key.isBlank()) {
            throw new IllegalStateException("Server response did not contain publicKeyBase64: " + response);
        }
        return key;
    }

    private static String readJsonString(String json, String field) {
        String needle = "\"" + field + "\"";
        int keyIndex = json.indexOf(needle);
        if (keyIndex < 0) {
            return null;
        }
        int colon = json.indexOf(':', keyIndex + needle.length());
        if (colon < 0) {
            return null;
        }
        int start = colon + 1;
        while (start < json.length() && Character.isWhitespace(json.charAt(start))) {
            start++;
        }
        if (start >= json.length() || json.charAt(start) != '"') {
            return null;
        }
        StringBuilder value = new StringBuilder();
        for (int i = start + 1; i < json.length(); i++) {
            char ch = json.charAt(i);
            if (ch == '"') {
                return value.toString();
            }
            if (ch == '\\' && i + 1 < json.length()) {
                char next = json.charAt(++i);
                switch (next) {
                    case '"' -> value.append('"');
                    case '\\' -> value.append('\\');
                    case '/' -> value.append('/');
                    case 'n' -> value.append('\n');
                    case 'r' -> value.append('\r');
                    case 't' -> value.append('\t');
                    default -> value.append(next);
                }
            } else {
                value.append(ch);
            }
        }
        return null;
    }

    private static void validateAccount(String account, String role) {
        if (account == null || !account.matches("\\d{16}")) {
            throw new IllegalArgumentException(role + " account must be exactly 16 digits.");
        }
    }

    private static PublicKey decodePublicKey(String publicKeyBase64) throws Exception {
        byte[] bytes = Base64.getDecoder().decode(publicKeyBase64.trim());
        return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(bytes));
    }

    private static String sha256Hex(byte[] input) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(input));
    }

    private static String paymentHash(UUID paymentId, String sender, String receiver,
                                      BigDecimal amount, String currency, long createdAt) throws Exception {
        String canonical = paymentId + "|"
                + sender + "|"
                + receiver + "|"
                + amount.stripTrailingZeros().toPlainString() + "|"
                + currency + "|"
                + createdAt;
        return sha256Hex(canonical.getBytes(StandardCharsets.UTF_8));
    }

    private static String jsonString(String value) {
        StringBuilder out = new StringBuilder();
        out.append('"');
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            switch (ch) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                default -> {
                    if (ch < 0x20) {
                        out.append(String.format("\\u%04x", (int) ch));
                    } else {
                        out.append(ch);
                    }
                }
            }
        }
        out.append('"');
        return out.toString();
    }

    private static String payloadJson(UUID paymentId, String sender, String receiver,
                                      BigDecimal amount, String currency, long createdAt,
                                      String payloadHash) {
        return "{\"paymentId\":" + jsonString(paymentId.toString())
                + ",\"senderAccountNumber\":" + jsonString(sender)
                + ",\"receiverAccountNumber\":" + jsonString(receiver)
                + ",\"amount\":" + amount.toPlainString()
                + ",\"currency\":" + jsonString(currency)
                + ",\"createdAt\":" + createdAt
                + ",\"payloadHash\":" + jsonString(payloadHash)
                + "}";
    }

    private static String packetJson(UUID packetId, String originDeviceId, long createdAt,
                                     int ttl, int hopCount, String ciphertext) {
        return "{\"packetId\":" + jsonString(packetId.toString())
                + ",\"originDeviceId\":" + jsonString(originDeviceId)
                + ",\"createdAt\":" + createdAt
                + ",\"ttl\":" + ttl
                + ",\"hopCount\":" + hopCount
                + ",\"ciphertext\":" + jsonString(ciphertext)
                + "}";
    }

    private static String encrypt(PublicKey publicKey, byte[] plaintext) throws Exception {
        SecureRandom random = new SecureRandom();
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(AES_KEY_BITS, random);
        SecretKey aesKey = keyGenerator.generateKey();

        byte[] iv = new byte[GCM_IV_BYTES];
        random.nextBytes(iv);

        Cipher aesCipher = Cipher.getInstance(AES_TRANSFORMATION);
        aesCipher.init(Cipher.ENCRYPT_MODE, aesKey, new GCMParameterSpec(GCM_TAG_BITS, iv));
        byte[] aesCiphertext = aesCipher.doFinal(plaintext);

        Cipher rsaCipher = Cipher.getInstance(RSA_TRANSFORMATION);
        rsaCipher.init(Cipher.ENCRYPT_MODE, publicKey);
        byte[] encryptedAesKey = rsaCipher.doFinal(aesKey.getEncoded());

        byte[] wire = new byte[encryptedAesKey.length + iv.length + aesCiphertext.length];
        System.arraycopy(encryptedAesKey, 0, wire, 0, encryptedAesKey.length);
        System.arraycopy(iv, 0, wire, encryptedAesKey.length, iv.length);
        System.arraycopy(aesCiphertext, 0, wire, encryptedAesKey.length + iv.length, aesCiphertext.length);
        return Base64.getEncoder().encodeToString(wire);
    }

}
